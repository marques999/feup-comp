class Sample2 {
public static void myFunction() {
	int i = 5;
	while (i > 0)
	{
	i--;
	}
}
}