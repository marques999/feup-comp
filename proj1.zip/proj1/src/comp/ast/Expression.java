package comp.ast;
public interface Expression
{
	public String getValue();
	public String getType();
}