class Sample {
public static void myFunction(int[] a) {
	for (int i = 0; i < a.length; i++)
	{
	a[i] = i;
	i--;
	}
}
}