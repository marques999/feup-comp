class Mini {
	public static long myFunction() {
		int a = 3;
		long b = 2L;
		long c = a * b;
		while (c > 0)
			c--;
		return c;
	}
}